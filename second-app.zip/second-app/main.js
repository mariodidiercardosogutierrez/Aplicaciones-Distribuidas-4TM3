var express = require('express');
var app = express(); //Contenedor de Endpoints o WS Restful

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get("/", async function (request, response) {
    r ={
      'message':'El servidor esta vivo ou yeah ...'
    };
    response.json(r);
});

app.get("/ruta1", async function (req, res) {
    let r = {'dato': 2,'valor': 'Mario Didier'};
    res.json(r);
});


app.listen(3000, function() {
    console.log('Aplicación ejemplo, escuchando el puerto 3000!');
});
